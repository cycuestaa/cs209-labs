package edu.virginia.engine.display;

import edu.virginia.engine.util.GameClock;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class AnimatedSprite extends Sprite {

    public ArrayList<Animation> animations;
    public boolean playing;
    public String fileName;
    public ArrayList<BufferedImage> frames;
    public int currentFrame;
    public int startFrame;
    public int endFrame;
    static final int DEFAULT_ANIMATION_SPEED = 1;
    public int animationSpeed;
    public GameClock gameClock;

    public AnimatedSprite(String id, String filename,Point pos){
        super(id,filename);
        this.gameClock=new GameClock();
        this.animationSpeed = DEFAULT_ANIMATION_SPEED;

    }

    public void initGameClock(){
        if (this.gameClock == null) {
            this.gameClock = new GameClock();
        }
    }

    public void setAnimation(ArrayList<Animation> newAnimations) {
        this.animations = newAnimations;
    }

    public void setAnimationSpeed(int newAnimationSpeed) {
        this.animationSpeed = newAnimationSpeed;
    }

    public void setStartFrame(int s) {
        this.startFrame = s;
    }
    public int getStartFrame() {return this.startFrame}


    public void setEndFrame(int e) {
        this.endFrame = s;
    }
    public int getEndFrame() {return this.endFrame}


    public void initFrame() {
        this.currentFrame = this.getStartFrame();
    }

    public void incrementFrame() {
        this.currentFrame += 1;
    }


    public void draw(int startFrame, int endFrame, Graphics g) {

        if (playing != false) {
            this.setStartFrame(startFrame);
            this.setEndFrame((endFrame));

            this.initGameClock();
            this.initFrame();
            BufferedImage image;
            double elapsedTime;
            while (true) {
                elapsedTime = this.gameClock.getElapsedTime();
                if (elapsedTime >= this.animationSpeed) {
                    image = this.frames.get(this.currentFrame);
                    this.setImage(image);
                    super.draw(g);
                    this.gameClock.resetGameClock();
                    this.incrementFrame();
                }
            }

        }
    }

}
